# -*- coding: utf-8 -*-
"""
Created on Sat Sep 23 13:44:40 2017

@author: Wael
"""

"""
__________________________________________

Import Packages
_________________________________________

"""
from keras.applications.resnet50 import ResNet50
from keras.preprocessing import image
from keras.applications.resnet50 import preprocess_input, decode_predictions
import numpy as np
from keras.layers import GlobalAveragePooling2D,Dropout,BatchNormalization ,Input, Dense, Convolution2D, MaxPooling2D, AveragePooling2D, ZeroPadding2D, Dropout, Flatten, merge, Reshape, Activation
from keras.models import Model
from keras.optimizers import SGD
from keras.utils import np_utils
import numpy as np
import argparse
#import cv2
import scipy.io
from keras.datasets import cifar10
from keras.preprocessing.image import ImageDataGenerator
import tensorflow as tf
from keras.callbacks import ModelCheckpoint,CSVLogger
import keras.backend as K
import hdf5storage     ####*************
import warnings
warnings.filterwarnings('ignore')

epochs=1000
batch_size=32



"""
________________________________________
Load Data--Set
________________________________________
"""
#
#

data_read=hdf5storage.loadmat('data.mat');
data_labels_read=hdf5storage.loadmat('Labels.mat');

data_matrix=data_read['a'];
data_matrix_labels=data_labels_read['b'];
#
data_matrix=data_matrix.astype('float32')
data_matrix_labels=data_matrix_labels.astype('float32')

data_matrix=np.reshape(data_matrix,[np.shape(data_matrix)[0],200,200,3],order='F')
#data_matrix_labels=np.reshape(data_matrix_labels,[np.shape(data_matrix_labels)[0],40000,1],order='F')
#data_matrix_labels= np.expand_dims(data_matrix_labels, axis=1)

X_train=data_matrix[0:3102,:,:,:]
y_train=data_matrix_labels[0:3102,:]                        

X_validation=data_matrix[3102:3877,:,:,:]
y_validation=data_matrix_labels[3102:3877,:]
                
#y_validation=np.squeeze(np.squeeze(y_validation,axis=2),axis=1);

##
##X_testing=data_matrix[3877:4846,:,:,:];
##y_testing=data_matrix_labels[3877:4846,:];
##y_testing=np.squeeze(np.squeeze(y_testing,axis=1),axis=2);
#
#
#
"""
___________________________

Build Model
___________________________
"""
model = ResNet50(weights='imagenet',include_top=False,input_shape=(200,200,3))
x = model.layers[173].output
x = GlobalAveragePooling2D()(x)
predictions = Dense(1, activation='sigmoid')(x)
model = Model(inputs=model.input, outputs=predictions)

"""
______________________

Freezing Weights
______________________
"""
for layer in model.layers[0:175]:
    layer.trainable = False

"""
______________________

Compile the model
_____________________

"""
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

#"""
#__________________________
#
#     Data Augmentation
#__________________________
#"""
seed=1
datagen = ImageDataGenerator(
       rotation_range=0,
       horizontal_flip=True,
       height_shift_range=0.1,
       width_shift_range=0.1,
       vertical_flip=True,
       zoom_range=0.2,
       
)  
datagen.fit(X_train,augment=True,seed = seed)
#
#
#"""
#___________________________________________
#
# Train the model
#___________________________________________
#"""
#
filepath='Weights.hdf5'
checkpoint = ModelCheckpoint(filepath, monitor='', verbose=1, save_best_only=True, mode='max')
csv_logger = CSVLogger('run.csv')
callbacks_list = [checkpoint,csv_logger]

## there is a problem in dimensions this is the error:
# Error when checking target: expected dense_6 to have 2 dimensions, but got array with shape (32, 1, 1, 1)
model.fit_generator(datagen.flow(X_train,y_train , batch_size=batch_size),
                       steps_per_epoch=X_train.shape[0] // batch_size,
                        epochs=epochs,verbose=1,validation_data=(X_validation,y_validation),callbacks=callbacks_list)



model.save('New_Trained_Weights/breast_cancer_ResNet50_Weights.h5')


